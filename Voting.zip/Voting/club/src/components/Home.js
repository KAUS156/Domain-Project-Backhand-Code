
import React from 'react';
import { Link } from 'react-router-dom'; // Step 1: Import the Link component

const Home = () => {
  return (
    <div>
      
      <p>Club</p>
      <ul>
      <p>
          <Link to="/awareness">Awareness</Link> {/* Step 2: Use the Link component */}
        </p>
        <br>
        </br>
        <p>
          <Link to="/workshop">Workshop</Link> {/* Step 2: Use the Link component */}
          </p>
      </ul>
    </div>
  );
};

export default Home;
