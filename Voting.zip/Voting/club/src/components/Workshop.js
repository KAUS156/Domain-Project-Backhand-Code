
import React from 'react';

const Workshop = () => {
  return (
    <div>
      <h2>Workshop Component</h2>
      <p>This is the Workshop component.</p>
    </div>
  );
};

export default Workshop;
