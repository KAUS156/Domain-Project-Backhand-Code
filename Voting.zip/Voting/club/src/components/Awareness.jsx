
import React from 'react';
import './Awarness.css'

const Awareness = () => {
  return (
    <div>
      <h2>Awareness Component</h2>
      <p>This is the Awareness component.</p>
      <div className="PostBox">
        <div className="card">
          <div className="card-header">
           <h1>Posts</h1>
          </div>
          <div className='postbox' style={{"border":"1px solid red", }}>
          <div className='post' style={{"border":"1px solid blue","padding":"10px"}}>
          <img src="/299060.jpg" alt="" />
          <p>post1 text</p>
          </div>
          <div className='post' style={{"border":"1px solid blue","padding":"10px"}}>
          <img src="../Assets/299060.jpg" alt="" />
          <p>post2 text</p>
          </div>
          <div className='post' style={{"border":"1px solid blue","padding":"10px"}}>
          <img src="../Assets/299060.jpg" alt="" />
          <p>post3 text</p>
          </div>
         
          
        </div>
        <form action=''  className="PostBar">
          <textarea type="text" />
          <input type="file" />
          <button type='submit' id='send'>send</button>
        </form>
     </div>
   
    </div>
    </div>
  );
};

export default Awareness;
