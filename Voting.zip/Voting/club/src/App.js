
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; 
import Awareness from './components/Awareness';
import Workshop from './components/Workshop';
import Home from './components/Home'; 



const App = () => {
  return (
    <Router>
      <Routes> {/* Use the Routes component */}
        <Route exact path="/" element={<Home />} /> {/* Wrap Route inside Routes */}
        <Route path="/awareness" element={<Awareness />} /> {/* Wrap Route inside Routes */}
        <Route path="/workshop" element={<Workshop />} /> {/* Wrap Route inside Routes */}
      </Routes> {/* Close the Routes component */}
    </Router>
  );
};

export default App;
